class WalkInPatient {
  String id;
  String fname;
  String age;

  WalkInPatient({required this.id, required this.fname, required this.age});
}
