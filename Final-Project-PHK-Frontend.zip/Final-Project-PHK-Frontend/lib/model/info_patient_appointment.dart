//info id fname age apdatetime doctor
class AppointmentPatient {
  String id;
  String fname;
  String age;
  String apdatetime;
  String doctor;

  AppointmentPatient(
      {required this.id,
      required this.fname,
      required this.age,
      required this.apdatetime,
      required this.doctor});
}
